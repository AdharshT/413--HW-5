package com.company;
//To run this program check out the Main.java

// Adharsh Thiagarajan

public interface TransactionInterface {
    void execute();
}
